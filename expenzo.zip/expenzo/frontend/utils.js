window.formatMoney = function formatMoney(value) {
  return `₹${Number(value).toFixed(2)}`;
};

window.safeDate = function safeDate(value) {
  return new Date(value).toLocaleDateString("en-IN");
};
