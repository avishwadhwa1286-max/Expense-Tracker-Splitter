const { useEffect, useMemo, useState } = React;

function AuthScreen({ onAuth }) {
  const [isSignup, setIsSignup] = useState(true);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: ""
  });
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const endpoint = isSignup ? "/api/signup" : "/api/login";
      const payload = isSignup
        ? { name: form.name, email: form.email, password: form.password }
        : { email: form.email, password: form.password };

      const data = await window.api(endpoint, "POST", payload);
      localStorage.setItem("token", data.token);
      onAuth(data.user);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <h1>Mini Expense Split App</h1>
        <p>{isSignup ? "Create account" : "Login to continue"}</p>

        {error && <div className="error">{error}</div>}

        <form onSubmit={submit}>
          {isSignup && (
            <input
              placeholder="Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          )}

          <input
            type="email"
            placeholder="Email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />

          <input
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />

          <button type="submit">{isSignup ? "Signup" : "Login"}</button>
        </form>

        <button className="link-btn" onClick={() => setIsSignup(!isSignup)}>
          {isSignup ? "Already have an account? Login" : "No account? Signup"}
        </button>
      </div>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [friends, setFriends] = useState([]);
  const [splits, setSplits] = useState([]);
  const [settlements, setSettlements] = useState([]);
  const [balances, setBalances] = useState([]);
  const [error, setError] = useState("");

  const [expenseForm, setExpenseForm] = useState({
    title: "",
    amount: "",
    category: ""
  });
  const [editingExpenseId, setEditingExpenseId] = useState(null);

  const [friendEmail, setFriendEmail] = useState("");

  const [splitForm, setSplitForm] = useState({
    friendId: "",
    description: "",
    amount: "",
    paidBy: "me"
  });

  const [settlementForm, setSettlementForm] = useState({
    friendId: "",
    amount: "",
    paidBy: "me"
  });

  const loadData = async () => {
    try {
      const [me, ex, fr, sp, st, ba] = await Promise.all([
        window.api("/api/me"),
        window.api("/api/expenses"),
        window.api("/api/friends"),
        window.api("/api/splits"),
        window.api("/api/settlements"),
        window.api("/api/balances")
      ]);

      setUser(me);
      setExpenses(ex);
      setFriends(fr);
      setSplits(sp);
      setSettlements(st);
      setBalances(ba);
    } catch (err) {
      localStorage.removeItem("token");
      setUser(null);
    }
  };

  useEffect(() => {
    if (localStorage.getItem("token")) {
      loadData();
    }
  }, []);

  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
    setExpenses([]);
    setFriends([]);
    setSplits([]);
    setSettlements([]);
    setBalances([]);
  };

  const totalExpense = useMemo(() => {
    return expenses.reduce((sum, item) => sum + Number(item.amount), 0);
  }, [expenses]);

  const totalOwed = useMemo(() => {
    return balances
      .filter((item) => item.balance > 0)
      .reduce((sum, item) => sum + item.balance, 0);
  }, [balances]);

  const totalYouOwe = useMemo(() => {
    return balances
      .filter((item) => item.balance < 0)
      .reduce((sum, item) => sum + Math.abs(item.balance), 0);
  }, [balances]);

  const submitExpense = async (e) => {
    e.preventDefault();
    setError("");

    try {
      if (!expenseForm.title || !expenseForm.amount || !expenseForm.category) {
        throw new Error("Please fill all expense fields");
      }

      if (editingExpenseId) {
        await window.api(`/api/expenses/${editingExpenseId}`, "PUT", {
          title: expenseForm.title,
          amount: Number(expenseForm.amount),
          category: expenseForm.category
        });
      } else {
        await window.api("/api/expenses", "POST", {
          title: expenseForm.title,
          amount: Number(expenseForm.amount),
          category: expenseForm.category
        });
      }

      setExpenseForm({ title: "", amount: "", category: "" });
      setEditingExpenseId(null);
      loadData();
    } catch (err) {
      setError(err.message);
    }
  };

  const editExpense = (expense) => {
    setEditingExpenseId(expense._id);
    setExpenseForm({
      title: expense.title,
      amount: String(expense.amount),
      category: expense.category
    });
  };

  const cancelEdit = () => {
    setEditingExpenseId(null);
    setExpenseForm({ title: "", amount: "", category: "" });
  };

  const deleteExpense = async (id) => {
    await window.api(`/api/expenses/${id}`, "DELETE");
    loadData();
  };

  const addFriend = async (e) => {
    e.preventDefault();
    setError("");

    try {
      await window.api("/api/friends", "POST", { email: friendEmail });
      setFriendEmail("");
      loadData();
    } catch (err) {
      setError(err.message);
    }
  };

  const deleteFriend = async (id) => {
    await window.api(`/api/friends/${id}`, "DELETE");
    loadData();
  };

  const addSplit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      await window.api("/api/splits", "POST", {
        friendId: splitForm.friendId,
        description: splitForm.description,
        amount: Number(splitForm.amount),
        paidBy: splitForm.paidBy
      });

      setSplitForm({
        friendId: "",
        description: "",
        amount: "",
        paidBy: "me"
      });

      loadData();
    } catch (err) {
      setError(err.message);
    }
  };

  const addSettlement = async (e) => {
    e.preventDefault();
    setError("");

    try {
      await window.api("/api/settlements", "POST", {
        friendId: settlementForm.friendId,
        amount: Number(settlementForm.amount),
        paidBy: settlementForm.paidBy
      });

      setSettlementForm({
        friendId: "",
        amount: "",
        paidBy: "me"
      });

      loadData();
    } catch (err) {
      setError(err.message);
    }
  };

  if (!user) {
    return <AuthScreen onAuth={setUser} />;
  }

  return (
    <div className="page">
      <header className="topbar">
        <div>
          <h1>Welcome, {user.name}</h1>
          <p>{user.email}</p>
        </div>
        <button onClick={logout}>Logout</button>
      </header>

      {error && <div className="error wide">{error}</div>}

      <section className="grid">
        <div className="card summary">
          <h2>Dashboard</h2>
          <p>Total Personal Expenses: <strong>{window.formatMoney(totalExpense)}</strong></p>
          <p>Total You Are Owed: <strong className="green">{window.formatMoney(totalOwed)}</strong></p>
          <p>Total You Owe: <strong className="red">{window.formatMoney(totalYouOwe)}</strong></p>
          <p>Friends Count: <strong>{friends.length}</strong></p>
        </div>

        <div className="card">
          <h2>{editingExpenseId ? "Edit Expense" : "Add Expense"}</h2>
          <form onSubmit={submitExpense}>
            <input
              placeholder="Title"
              value={expenseForm.title}
              onChange={(e) => setExpenseForm({ ...expenseForm, title: e.target.value })}
            />
            <input
              type="number"
              placeholder="Amount"
              value={expenseForm.amount}
              onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })}
            />
            <input
              placeholder="Category"
              value={expenseForm.category}
              onChange={(e) => setExpenseForm({ ...expenseForm, category: e.target.value })}
            />
            <button type="submit">{editingExpenseId ? "Update Expense" : "Add Expense"}</button>
            {editingExpenseId && (
              <button type="button" className="secondary" onClick={cancelEdit}>
                Cancel Edit
              </button>
            )}
          </form>
        </div>

        <div className="card">
          <h2>Add Friend</h2>
          <form onSubmit={addFriend}>
            <input
              type="email"
              placeholder="Friend email"
              value={friendEmail}
              onChange={(e) => setFriendEmail(e.target.value)}
            />
            <button type="submit">Add Friend</button>
          </form>
        </div>

        <div className="card">
          <h2>Add Shared Expense</h2>
          <form onSubmit={addSplit}>
            <select
              value={splitForm.friendId}
              onChange={(e) => setSplitForm({ ...splitForm, friendId: e.target.value })}
            >
              <option value="">Select Friend</option>
              {friends.map((friend) => (
                <option key={friend._id} value={friend.friendUser._id}>
                  {friend.friendUser.name}
                </option>
              ))}
            </select>

            <input
              placeholder="Description"
              value={splitForm.description}
              onChange={(e) => setSplitForm({ ...splitForm, description: e.target.value })}
            />

            <input
              type="number"
              placeholder="Amount"
              value={splitForm.amount}
              onChange={(e) => setSplitForm({ ...splitForm, amount: e.target.value })}
            />

            <select
              value={splitForm.paidBy}
              onChange={(e) => setSplitForm({ ...splitForm, paidBy: e.target.value })}
            >
              <option value="me">I paid</option>
              <option value="friend">Friend paid</option>
            </select>

            <button type="submit">Add Shared Expense</button>
          </form>
        </div>

        <div className="card">
          <h2>Record Settlement</h2>
          <form onSubmit={addSettlement}>
            <select
              value={settlementForm.friendId}
              onChange={(e) =>
                setSettlementForm({ ...settlementForm, friendId: e.target.value })
              }
            >
              <option value="">Select Friend</option>
              {friends.map((friend) => (
                <option key={friend._id} value={friend.friendUser._id}>
                  {friend.friendUser.name}
                </option>
              ))}
            </select>

            <input
              type="number"
              placeholder="Amount"
              value={settlementForm.amount}
              onChange={(e) =>
                setSettlementForm({ ...settlementForm, amount: e.target.value })
              }
            />

            <select
              value={settlementForm.paidBy}
              onChange={(e) =>
                setSettlementForm({ ...settlementForm, paidBy: e.target.value })
              }
            >
              <option value="me">I paid friend</option>
              <option value="friend">Friend paid me</option>
            </select>

            <button type="submit">Record Settlement</button>
          </form>
        </div>
      </section>

      <section className="grid lower-grid">
        <div className="card">
          <h2>Expenses</h2>
          {expenses.length === 0 ? (
            <p className="muted">No expenses yet</p>
          ) : (
            expenses.map((item) => (
              <div key={item._id} className="list-item">
                <div>
                  <strong>{item.title}</strong>
                  <div>{item.category}</div>
                  <div>{window.formatMoney(item.amount)}</div>
                  <div className="muted">{window.safeDate(item.date)}</div>
                </div>
                <div className="button-group">
                  <button className="small secondary" onClick={() => editExpense(item)}>
                    Edit
                  </button>
                  <button className="small danger" onClick={() => deleteExpense(item._id)}>
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="card">
          <h2>Friends</h2>
          {friends.length === 0 ? (
            <p className="muted">No friends added</p>
          ) : (
            friends.map((item) => (
              <div key={item._id} className="list-item">
                <div>
                  <strong>{item.friendUser.name}</strong>
                  <div>{item.friendUser.email}</div>
                </div>
                <button className="small danger" onClick={() => deleteFriend(item._id)}>
                  Remove
                </button>
              </div>
            ))
          )}
        </div>

        <div className="card">
          <h2>Shared Expenses</h2>
          {splits.length === 0 ? (
            <p className="muted">No shared expenses yet</p>
          ) : (
            splits.map((item) => (
              <div key={item._id} className="list-item">
                <div>
                  <strong>{item.description}</strong>
                  <div>Friend: {item.friend.name}</div>
                  <div>Amount: {window.formatMoney(item.amount)}</div>
                  <div>{item.paidBy === "me" ? "You paid" : "Friend paid"}</div>
                  <div className="muted">{window.safeDate(item.date)}</div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="card">
          <h2>Balances</h2>
          {balances.length === 0 ? (
            <p className="muted">No balances yet</p>
          ) : (
            balances.map((item) => (
              <div key={item.friend._id} className="list-item">
                <div>
                  <strong>{item.friend.name}</strong>
                  <div>{item.friend.email}</div>
                </div>
                <div className={item.balance >= 0 ? "green" : "red"}>
                  {item.balance >= 0
                    ? `You are owed ${window.formatMoney(item.balance)}`
                    : `You owe ${window.formatMoney(Math.abs(item.balance))}`}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="card">
          <h2>Settlements</h2>
          {settlements.length === 0 ? (
            <p className="muted">No settlements yet</p>
          ) : (
            settlements.map((item) => (
              <div key={item._id} className="list-item">
                <div>
                  <strong>{item.friend.name}</strong>
                  <div>{window.formatMoney(item.amount)}</div>
                  <div>{item.paidBy === "me" ? "You paid friend" : "Friend paid you"}</div>
                  <div className="muted">{window.safeDate(item.date)}</div>
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
