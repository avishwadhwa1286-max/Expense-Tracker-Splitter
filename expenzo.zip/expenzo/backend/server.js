const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const path = require("path");
const { User, Expense, Friend, Split, Settlement } = require("./models");
const {
  createToken,
  hashPassword,
  comparePassword,
  authMiddleware
} = require("./auth");

dotenv.config();

const app = express();
app.use(express.json());

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch((error) => {
    console.error("MongoDB connection failed:", error.message);
    process.exit(1);
  });

app.post("/api/signup", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      return res.status(400).json({ message: "Email already exists" });
    }

    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password: await hashPassword(password)
    });

    const token = createToken(user._id);

    res.json({
      token,
      user: { _id: user._id, name: user.name, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ message: "Signup failed" });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const ok = await comparePassword(password, user.password);
    if (!ok) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = createToken(user._id);

    res.json({
      token,
      user: { _id: user._id, name: user.name, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ message: "Login failed" });
  }
});

app.get("/api/me", authMiddleware, async (req, res) => {
  res.json({
    _id: req.user._id,
    name: req.user.name,
    email: req.user.email
  });
});

app.get("/api/expenses", authMiddleware, async (req, res) => {
  const expenses = await Expense.find({ user: req.user._id }).sort({ date: -1 });
  res.json(expenses);
});

app.post("/api/expenses", authMiddleware, async (req, res) => {
  try {
    const { title, amount, category } = req.body;

    if (!title || !amount || !category) {
      return res.status(400).json({ message: "Title, amount, and category are required" });
    }

    const expense = await Expense.create({
      user: req.user._id,
      title,
      amount,
      category
    });

    res.json(expense);
  } catch (error) {
    res.status(500).json({ message: "Failed to add expense" });
  }
});

app.put("/api/expenses/:id", authMiddleware, async (req, res) => {
  try {
    const { title, amount, category } = req.body;

    const expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!expense) {
      return res.status(404).json({ message: "Expense not found" });
    }

    expense.title = title || expense.title;
    expense.amount = amount || expense.amount;
    expense.category = category || expense.category;

    await expense.save();
    res.json(expense);
  } catch (error) {
    res.status(500).json({ message: "Failed to update expense" });
  }
});

app.delete("/api/expenses/:id", authMiddleware, async (req, res) => {
  const deleted = await Expense.findOneAndDelete({
    _id: req.params.id,
    user: req.user._id
  });

  if (!deleted) {
    return res.status(404).json({ message: "Expense not found" });
  }

  res.json({ message: "Expense deleted" });
});

app.get("/api/friends", authMiddleware, async (req, res) => {
  const friends = await Friend.find({ user: req.user._id }).populate("friendUser", "name email");
  res.json(friends);
});

app.post("/api/friends", authMiddleware, async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: "Friend email is required" });
    }

    const friendUser = await User.findOne({ email: email.toLowerCase() });
    if (!friendUser) {
      return res.status(404).json({ message: "User not found" });
    }

    if (String(friendUser._id) === String(req.user._id)) {
      return res.status(400).json({ message: "You cannot add yourself" });
    }

    const exists = await Friend.findOne({
      user: req.user._id,
      friendUser: friendUser._id
    });

    if (exists) {
      return res.status(400).json({ message: "Friend already added" });
    }

    const friend = await Friend.create({
      user: req.user._id,
      friendUser: friendUser._id
    });

    const populated = await Friend.findById(friend._id).populate("friendUser", "name email");
    res.json(populated);
  } catch (error) {
    res.status(500).json({ message: "Failed to add friend" });
  }
});

app.delete("/api/friends/:id", authMiddleware, async (req, res) => {
  const deleted = await Friend.findOneAndDelete({
    _id: req.params.id,
    user: req.user._id
  });

  if (!deleted) {
    return res.status(404).json({ message: "Friend not found" });
  }

  res.json({ message: "Friend removed" });
});

app.get("/api/splits", authMiddleware, async (req, res) => {
  const splits = await Split.find({ user: req.user._id })
    .populate("friend", "name email")
    .sort({ date: -1 });
  res.json(splits);
});

app.post("/api/splits", authMiddleware, async (req, res) => {
  try {
    const { friendId, description, amount, paidBy } = req.body;

    if (!friendId || !description || !amount || !paidBy) {
      return res.status(400).json({ message: "All split fields are required" });
    }

    const friendLink = await Friend.findOne({
      user: req.user._id,
      friendUser: friendId
    });

    if (!friendLink) {
      return res.status(400).json({ message: "Friend must exist in your list" });
    }

    const split = await Split.create({
      user: req.user._id,
      friend: friendId,
      description,
      amount,
      paidBy
    });

    const populated = await Split.findById(split._id).populate("friend", "name email");
    res.json(populated);
  } catch (error) {
    res.status(500).json({ message: "Failed to add split expense" });
  }
});

app.get("/api/settlements", authMiddleware, async (req, res) => {
  const settlements = await Settlement.find({ user: req.user._id })
    .populate("friend", "name email")
    .sort({ date: -1 });
  res.json(settlements);
});

app.post("/api/settlements", authMiddleware, async (req, res) => {
  try {
    const { friendId, amount, paidBy } = req.body;

    if (!friendId || !amount || !paidBy) {
      return res.status(400).json({ message: "All settlement fields are required" });
    }

    const friendLink = await Friend.findOne({
      user: req.user._id,
      friendUser: friendId
    });

    if (!friendLink) {
      return res.status(400).json({ message: "Friend must exist in your list" });
    }

    const settlement = await Settlement.create({
      user: req.user._id,
      friend: friendId,
      amount,
      paidBy
    });

    const populated = await Settlement.findById(settlement._id).populate("friend", "name email");
    res.json(populated);
  } catch (error) {
    res.status(500).json({ message: "Failed to record settlement" });
  }
});

app.get("/api/balances", authMiddleware, async (req, res) => {
  const splits = await Split.find({ user: req.user._id }).populate("friend", "name email");
  const settlements = await Settlement.find({ user: req.user._id }).populate("friend", "name email");

  const balanceMap = {};

  for (const split of splits) {
    const friendId = String(split.friend._id);
    const half = Number(split.amount) / 2;

    if (!balanceMap[friendId]) {
      balanceMap[friendId] = {
        friend: {
          _id: split.friend._id,
          name: split.friend.name,
          email: split.friend.email
        },
        balance: 0
      };
    }

    if (split.paidBy === "me") {
      balanceMap[friendId].balance += half;
    } else {
      balanceMap[friendId].balance -= half;
    }
  }

  for (const settlement of settlements) {
    const friendId = String(settlement.friend._id);

    if (!balanceMap[friendId]) {
      balanceMap[friendId] = {
        friend: {
          _id: settlement.friend._id,
          name: settlement.friend.name,
          email: settlement.friend.email
        },
        balance: 0
      };
    }

    if (settlement.paidBy === "me") {
      balanceMap[friendId].balance -= Number(settlement.amount);
    } else {
      balanceMap[friendId].balance += Number(settlement.amount);
    }
  }

  res.json(Object.values(balanceMap));
});

app.use(express.static(path.join(__dirname, "../frontend")));

app.get("*", (req, res) => {
  if (req.path.startsWith("/api")) {
    return res.status(404).json({ message: "API route not found" });
  }
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
